// ProductPage.jsx

import React, { useState, useEffect } from 'react';

import axios from 'axios';

const ProductPage = () => {
  const [products, setProducts] = useState([]);

  useEffect(() => {
    const fetchProducts = async () => {
      const options = {
        method: 'GET',
        url: 'https://amazon-product-reviews-keywords.p.rapidapi.com/product/search',
        params: {
          keyword: 'iphone',
          country: 'US',
          category: 'aps',
        },
        headers: {
          'X-RapidAPI-Key': '340d19db38msha35c8bf6c68e367p1bdcb0jsn3adae1826136',
          'X-RapidAPI-Host': 'amazon-product-reviews-keywords.p.rapidapi.com',
        },
      };

      try {
        const response = await axios.request(options);
        setProducts(response.data); // Assuming the response contains an array of products
      } catch (error) {
        console.error('Error fetching products:', error);
      }
    };

    fetchProducts();
  }, []);

  return (
    <div>
      <h2>Products</h2>
      <ul>
        {products.map((product) => (
          <li key={product.id}>
            <h3>{product.name}</h3>
            <p>{product.description}</p>
            <button>Add to Cart</button>
            <button>Add to Favorites</button>
          </li>
        ))}
      </ul>

      
    </div>
  );
};

export default ProductPage;
