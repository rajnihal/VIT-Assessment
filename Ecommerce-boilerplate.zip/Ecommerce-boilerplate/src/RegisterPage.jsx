// RegisterPage.jsx

import React, { useState } from 'react';
import { Link, Route, Routes } from 'react-router-dom';
import ProductPage from './ProductPage';


const RegisterPage = () => {
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');

  const handleRegister = () => {
    // Add your registration logic here
    // This is just a placeholder, you may need to make an API call to register the user
    console.log('User registered:', { username, password });
    // Optionally, you can redirect the user to the login page or perform any other actions
  };

  return (
    <div>
      <h2>Register</h2>
      <form>
        <label>
          Username:
          <input type="text" value={username} onChange={(e) => setUsername(e.target.value)} />
        </label>
        <br />
        <label>
          Password:
          <input type="password" value={password} onChange={(e) => setPassword(e.target.value)} />
        </label>
        <label>
          Re-enter Password:
          <input type="password" value={password} onChange={(e) => setPassword(e.target.value)} />
        </label>
        <br />
        <Link to="products">
        <button type="button" onClick={handleRegister}>
          Register
        </button>
        </Link>
      </form>

      <Routes>
        <Route path="register/products" element={<ProductPage />} />
        {/* <Route path="register" element={<RegisterPage />} /> */}
      </Routes>
    </div>
  );
};

export default RegisterPage;
