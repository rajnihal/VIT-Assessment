// App.jsx

import React from 'react';
import { BrowserRouter as Router, Route, Routes } from 'react-router-dom';
import AuthenticationPage from './AuthenticationPage';
import LoginPage from './LoginPage';
import RegisterPage from './RegisterPage';
import ProductPage from './ProductPage';
import CartPage from './CartPage'; // Import the CartPage component

const App = () => {
  return (
    <Router>
      <div>
        <h1>Welcome to Flipkart</h1>
      </div>
      <Routes>
        <Route path="/" element={<AuthenticationPage />} />
        <Route path="/login" element={<LoginPage />} />
        <Route path="/register" element={<RegisterPage />} />
        <Route path="login/products" element={<ProductPage />} />
        <Route path="register/products" element={<ProductPage />} />
        <Route path="/cart" element={<CartPage />} /> {/* Add route for CartPage */}
      </Routes>
    </Router>
  );
};

export default App;
