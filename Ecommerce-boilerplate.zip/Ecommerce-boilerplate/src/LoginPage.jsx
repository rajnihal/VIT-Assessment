// LoginPage.jsx

import React, { useState } from "react";
import { Link, Route, Routes } from "react-router-dom";
import ProductPage from "./ProductPage";

const LoginPage = () => {
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");

  const handleLogin = () => {
    // Implement login logic here
    // Redirect to the main product page on successful login
  };

  return (
    <div>
      <h3>Login</h3>
      <form>
        <label>
          Username:
          <input
            type="text"
            value={username}
            onChange={(e) => setUsername(e.target.value)}
          />
        </label>
        <br />
        <label>
          Password:
          <input
            type="password"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
          />
        </label>
        <br />
        <Link to="products">
          <button type="button" onClick={handleLogin}>
            Login
          </button>
        </Link>
      </form>

      <Routes>
        <Route path="login/products" element={<ProductPage />} />
      </Routes>
    </div>
  );
};

export default LoginPage;
